@echo off
REM One-click setup and run for Windows
cd /d "%~dp0"
if not exist .venv (
    python -m venv .venv || py -m venv .venv
)
call .venv\Scripts\activate.bat
pip install -r requirements.txt
echo.
echo Open http://127.0.0.1:5000 in your browser. Admin: admin@food.com / Admin@123
python app.py
pause
