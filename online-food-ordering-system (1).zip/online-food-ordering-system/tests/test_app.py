import pytest

from app import create_app


@pytest.fixture
def app(tmp_path):
    return create_app({"TESTING": True, "DATABASE": str(tmp_path / "test.db"), "CSRF_ENABLED": False})


@pytest.fixture
def client(app):
    return app.test_client()


def register(client, email="user@test.com", password="secret1", name="Test User"):
    return client.post("/register", data={"name": name, "email": email, "password": password,
                                          "address": "12 Test Street"}, follow_redirects=True)


def login(client, email="user@test.com", password="secret1"):
    return client.post("/login", data={"email": email, "password": password}, follow_redirects=True)


def login_admin(client):
    return login(client, "admin@food.com", "Admin@123")


def place_order(client):
    client.post("/cart/add/1")
    client.post("/cart/add/1")
    return client.post("/checkout", data={"address": "12 Test Street", "payment_method": "UPI"},
                       follow_redirects=True)


def test_menu_shows_seeded_items(client):
    r = client.get("/")
    assert r.status_code == 200 and b"Margherita Pizza" in r.data


def test_menu_search_and_category_filter(client):
    assert b"Cold Coffee" in client.get("/?q=coffee").data
    assert b"Margherita" not in client.get("/?q=coffee").data
    assert b"Veg Burger" in client.get("/?category=Burgers").data


def test_register_and_login(client):
    assert b"Registration successful" in register(client).data
    assert b"Hi, Test User" in login(client).data


def test_duplicate_email_rejected(client):
    register(client)
    assert b"already registered" in register(client).data


def test_short_password_rejected(client):
    assert b"at least 6 characters" in register(client, password="123").data


def test_invalid_login(client):
    assert b"Invalid email or password" in login(client, "nobody@test.com", "x").data


def test_cart_add_update_total(client):
    client.post("/cart/add/1")
    client.post("/cart/add/1")
    assert "₹498.00".encode() in client.get("/cart").data
    client.post("/cart/update/1", data={"quantity": 0})
    assert b"cart is empty" in client.get("/cart").data


def test_checkout_requires_login(client):
    client.post("/cart/add/1")
    r = client.get("/checkout")
    assert r.status_code == 302 and "/login" in r.headers["Location"]


def test_place_order_empties_cart(client):
    register(client)
    login(client)
    r = place_order(client)
    assert b"Order #1 placed successfully" in r.data
    assert b"cart is empty" in client.get("/cart").data


def test_checkout_validation(client):
    register(client)
    login(client)
    client.post("/cart/add/1")
    r = client.post("/checkout", data={"address": "", "payment_method": "UPI"})
    assert b"address is required" in r.data


def test_customer_cannot_access_admin(client):
    register(client)
    login(client)
    assert client.get("/admin").status_code == 403


def test_admin_updates_order_status(client):
    register(client)
    login(client)
    place_order(client)
    client.post("/logout")
    login_admin(client)
    client.post("/admin/orders/1/status", data={"status": "Delivered"})
    assert b"Delivered" in client.get("/admin/orders").data


def test_admin_menu_crud(client):
    login_admin(client)
    client.post("/admin/menu/new", data={"name": "Test Dish", "category": "Test", "price": "55.50",
                                         "description": "d", "is_available": "on"})
    assert b"Test Dish" in client.get("/admin/menu").data
    client.post("/admin/menu/11/delete")
    assert b"Test Dish" not in client.get("/admin/menu").data


def test_customer_can_cancel_only_placed_order(client):
    register(client)
    login(client)
    place_order(client)
    assert b"Order cancelled" in client.post("/orders/1/cancel", follow_redirects=True).data
    assert b"Only orders" in client.post("/orders/1/cancel", follow_redirects=True).data


def test_user_cannot_view_other_users_order(client):
    register(client)
    login(client)
    place_order(client)
    client.post("/logout")
    register(client, email="other@test.com", name="Other")
    login(client, "other@test.com")
    assert client.get("/orders/1").status_code == 403


def test_csrf_enforced_when_enabled(tmp_path):
    app = create_app({"TESTING": True, "DATABASE": str(tmp_path / "c.db"), "CSRF_ENABLED": True})
    assert app.test_client().post("/cart/add/1").status_code == 400
