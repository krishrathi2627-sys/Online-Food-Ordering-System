"""Online Food Ordering System - Flask application."""
import os
import secrets
import sqlite3
from functools import wraps

from flask import (Flask, abort, flash, g, redirect, render_template, request,
                   session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ORDER_STATUSES = ["Placed", "Preparing", "Out for Delivery", "Delivered", "Cancelled"]
PAYMENT_METHODS = ["Cash on Delivery", "UPI", "Card"]

SEED_ITEMS = [
    ("Margherita Pizza", "Classic tomato, mozzarella and basil.", "Pizza", 24900),
    ("Paneer Tikka Pizza", "Smoky paneer tikka with onions and capsicum.", "Pizza", 29900),
    ("Veg Burger", "Crispy veg patty with lettuce and mayo.", "Burgers", 14900),
    ("Chicken Burger", "Juicy grilled chicken with cheese.", "Burgers", 17900),
    ("Paneer Butter Masala", "Creamy tomato gravy with soft paneer.", "Main Course", 22000),
    ("Veg Biryani", "Fragrant basmati rice with vegetables.", "Main Course", 19900),
    ("Masala Dosa", "Crisp dosa with spiced potato filling.", "South Indian", 12000),
    ("Gulab Jamun (2 pcs)", "Warm milk-solid dumplings in sugar syrup.", "Desserts", 6000),
    ("Fresh Lime Soda", "Sweet or salted, chilled.", "Beverages", 5000),
    ("Cold Coffee", "Thick, creamy cold coffee.", "Beverages", 9000),
]


# --------------------------------------------------------------------------
# Database helpers
# --------------------------------------------------------------------------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app_config("DATABASE"))
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def current_app_config(key):
    from flask import current_app
    return current_app.config[key]


def init_db():
    db = get_db()
    with open(os.path.join(BASE_DIR, "schema.sql"), encoding="utf-8") as f:
        db.executescript(f.read())
    if db.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        db.execute(
            "INSERT INTO users (name, email, password_hash, role) VALUES (?,?,?,'admin')",
            ("Administrator", "admin@food.com",
             generate_password_hash(os.environ.get("ADMIN_PASSWORD", "Admin@123"))),
        )
    if db.execute("SELECT COUNT(*) FROM menu_items").fetchone()[0] == 0:
        db.executemany(
            "INSERT INTO menu_items (name, description, category, price_cents) VALUES (?,?,?,?)",
            SEED_ITEMS,
        )
    db.commit()


# --------------------------------------------------------------------------
# Application factory
# --------------------------------------------------------------------------
def create_app(config=None):
    app = Flask(__name__)
    app.config.update(
        SECRET_KEY=os.environ.get("SECRET_KEY", "dev-change-me"),
        DATABASE=os.path.join(BASE_DIR, "food.db"),
        CSRF_ENABLED=True,
    )
    if config:
        app.config.update(config)

    with app.app_context():
        init_db()

    @app.teardown_appcontext
    def close_db(_exc):
        db = g.pop("db", None)
        if db is not None:
            db.close()

    @app.template_filter("money")
    def money(cents):
        return "\u20b9{:,.2f}".format((cents or 0) / 100)

    def csrf_token():
        if "csrf_token" not in session:
            session["csrf_token"] = secrets.token_hex(16)
        return session["csrf_token"]

    app.jinja_env.globals["csrf_token"] = csrf_token
    app.jinja_env.globals["ORDER_STATUSES"] = ORDER_STATUSES

    @app.before_request
    def load_user_and_check_csrf():
        uid = session.get("user_id")
        g.user = None
        if uid:
            g.user = get_db().execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
        if app.config["CSRF_ENABLED"] and request.method == "POST":
            expected = session.get("csrf_token")
            supplied = request.form.get("csrf_token", "")
            if not expected or not secrets.compare_digest(expected, supplied):
                abort(400, "Invalid CSRF token")

    @app.context_processor
    def inject_cart_count():
        return {"cart_count": sum(session.get("cart", {}).values())}

    # ---------------------------------------------------------------- guards
    def login_required(view):
        @wraps(view)
        def wrapped(*a, **kw):
            if g.user is None:
                flash("Please log in to continue.", "warning")
                return redirect(url_for("login", next=request.path))
            return view(*a, **kw)
        return wrapped

    def admin_required(view):
        @wraps(view)
        @login_required
        def wrapped(*a, **kw):
            if g.user["role"] != "admin":
                abort(403)
            return view(*a, **kw)
        return wrapped

    # ------------------------------------------------------------ cart utils
    def cart_details():
        cart = session.get("cart", {})
        lines, total = [], 0
        if cart:
            db = get_db()
            for item_id, qty in cart.items():
                row = db.execute("SELECT * FROM menu_items WHERE id = ?", (item_id,)).fetchone()
                if row is None:
                    continue
                subtotal = row["price_cents"] * qty
                total += subtotal
                lines.append({"item": row, "qty": qty, "subtotal": subtotal})
        return lines, total

    # ----------------------------------------------------------------- menu
    @app.route("/")
    def menu():
        q = request.args.get("q", "").strip()
        category = request.args.get("category", "").strip()
        sql, params = "SELECT * FROM menu_items WHERE is_available = 1", []
        if q:
            sql += " AND (name LIKE ? OR description LIKE ?)"
            params += [f"%{q}%", f"%{q}%"]
        if category:
            sql += " AND category = ?"
            params.append(category)
        sql += " ORDER BY category, name"
        db = get_db()
        items = db.execute(sql, params).fetchall()
        categories = [r[0] for r in db.execute(
            "SELECT DISTINCT category FROM menu_items WHERE is_available = 1 ORDER BY category")]
        return render_template("index.html", items=items, categories=categories,
                               q=q, category=category)

    # ----------------------------------------------------------------- auth
    @app.route("/register", methods=["GET", "POST"])
    def register():
        if request.method == "POST":
            name = request.form.get("name", "").strip()
            email = request.form.get("email", "").strip().lower()
            password = request.form.get("password", "")
            address = request.form.get("address", "").strip()
            error = None
            if not name or not email or "@" not in email:
                error = "A name and a valid email are required."
            elif len(password) < 6:
                error = "Password must be at least 6 characters."
            if error is None:
                db = get_db()
                try:
                    db.execute(
                        "INSERT INTO users (name, email, password_hash, address) VALUES (?,?,?,?)",
                        (name, email, generate_password_hash(password), address))
                    db.commit()
                except sqlite3.IntegrityError:
                    error = "That email is already registered."
                else:
                    flash("Registration successful. Please log in.", "success")
                    return redirect(url_for("login"))
            flash(error, "danger")
        return render_template("register.html")

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            email = request.form.get("email", "").strip().lower()
            password = request.form.get("password", "")
            user = get_db().execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
            if user is None or not check_password_hash(user["password_hash"], password):
                flash("Invalid email or password.", "danger")
            else:
                cart = session.get("cart", {})
                session.clear()
                session["user_id"] = user["id"]
                session["cart"] = cart
                nxt = request.args.get("next", "")
                if not nxt.startswith("/") or nxt.startswith("//"):
                    nxt = url_for("admin_dashboard" if user["role"] == "admin" else "menu")
                return redirect(nxt)
        return render_template("login.html")

    @app.route("/logout", methods=["POST"])
    def logout():
        session.clear()
        flash("You have been logged out.", "info")
        return redirect(url_for("menu"))

    # ----------------------------------------------------------------- cart
    @app.route("/cart")
    def cart():
        lines, total = cart_details()
        return render_template("cart.html", lines=lines, total=total)

    @app.route("/cart/add/<int:item_id>", methods=["POST"])
    def cart_add(item_id):
        item = get_db().execute(
            "SELECT * FROM menu_items WHERE id = ? AND is_available = 1", (item_id,)).fetchone()
        if item is None:
            abort(404)
        cart_data = session.get("cart", {})
        cart_data[str(item_id)] = min(cart_data.get(str(item_id), 0) + 1, 20)
        session["cart"] = cart_data
        flash(f"Added {item['name']} to your cart.", "success")
        return redirect(request.referrer or url_for("menu"))

    @app.route("/cart/update/<int:item_id>", methods=["POST"])
    def cart_update(item_id):
        try:
            qty = int(request.form.get("quantity", 1))
        except ValueError:
            qty = 1
        cart_data = session.get("cart", {})
        if qty <= 0:
            cart_data.pop(str(item_id), None)
        elif str(item_id) in cart_data:
            cart_data[str(item_id)] = min(qty, 20)
        session["cart"] = cart_data
        return redirect(url_for("cart"))

    @app.route("/cart/clear", methods=["POST"])
    def cart_clear():
        session["cart"] = {}
        return redirect(url_for("cart"))

    # ------------------------------------------------------------- checkout
    @app.route("/checkout", methods=["GET", "POST"])
    @login_required
    def checkout():
        lines, total = cart_details()
        if not lines:
            flash("Your cart is empty.", "warning")
            return redirect(url_for("menu"))
        if request.method == "POST":
            address = request.form.get("address", "").strip()
            payment = request.form.get("payment_method", "")
            if not address:
                flash("Delivery address is required.", "danger")
            elif payment not in PAYMENT_METHODS:
                flash("Please choose a payment method.", "danger")
            elif any(not l["item"]["is_available"] for l in lines):
                flash("Some items in your cart are no longer available.", "danger")
            else:
                db = get_db()
                cur = db.execute(
                    "INSERT INTO orders (user_id, total_cents, address, payment_method) VALUES (?,?,?,?)",
                    (g.user["id"], total, address, payment))
                order_id = cur.lastrowid
                db.executemany(
                    "INSERT INTO order_items (order_id, item_id, name, price_cents, quantity) VALUES (?,?,?,?,?)",
                    [(order_id, l["item"]["id"], l["item"]["name"], l["item"]["price_cents"], l["qty"])
                     for l in lines])
                db.commit()
                session["cart"] = {}
                flash(f"Order #{order_id} placed successfully!", "success")
                return redirect(url_for("order_detail", order_id=order_id))
        return render_template("checkout.html", lines=lines, total=total,
                               payment_methods=PAYMENT_METHODS)

    # --------------------------------------------------------------- orders
    @app.route("/orders")
    @login_required
    def orders():
        rows = get_db().execute(
            "SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC", (g.user["id"],)).fetchall()
        return render_template("orders.html", orders=rows)

    @app.route("/orders/<int:order_id>")
    @login_required
    def order_detail(order_id):
        db = get_db()
        order = db.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
        if order is None:
            abort(404)
        if order["user_id"] != g.user["id"] and g.user["role"] != "admin":
            abort(403)
        items = db.execute("SELECT * FROM order_items WHERE order_id = ?", (order_id,)).fetchall()
        return render_template("order_detail.html", order=order, items=items)

    @app.route("/orders/<int:order_id>/cancel", methods=["POST"])
    @login_required
    def order_cancel(order_id):
        db = get_db()
        order = db.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
        if order is None:
            abort(404)
        if order["user_id"] != g.user["id"]:
            abort(403)
        if order["status"] != "Placed":
            flash("Only orders that are still 'Placed' can be cancelled.", "danger")
        else:
            db.execute("UPDATE orders SET status = 'Cancelled' WHERE id = ?", (order_id,))
            db.commit()
            flash("Order cancelled.", "info")
        return redirect(url_for("order_detail", order_id=order_id))

    # ---------------------------------------------------------------- admin
    @app.route("/admin")
    @admin_required
    def admin_dashboard():
        db = get_db()
        stats = {
            "orders": db.execute("SELECT COUNT(*) FROM orders").fetchone()[0],
            "revenue": db.execute(
                "SELECT COALESCE(SUM(total_cents),0) FROM orders WHERE status != 'Cancelled'").fetchone()[0],
            "customers": db.execute("SELECT COUNT(*) FROM users WHERE role='customer'").fetchone()[0],
            "items": db.execute("SELECT COUNT(*) FROM menu_items").fetchone()[0],
        }
        recent = db.execute(
            "SELECT o.*, u.name AS customer FROM orders o JOIN users u ON u.id = o.user_id "
            "ORDER BY o.id DESC LIMIT 5").fetchall()
        return render_template("admin_dashboard.html", stats=stats, recent=recent)

    @app.route("/admin/menu")
    @admin_required
    def admin_menu():
        items = get_db().execute("SELECT * FROM menu_items ORDER BY category, name").fetchall()
        return render_template("admin_menu.html", items=items)

    def read_item_form():
        name = request.form.get("name", "").strip()
        description = request.form.get("description", "").strip()
        category = request.form.get("category", "").strip()
        try:
            price = round(float(request.form.get("price", "")) * 100)
        except ValueError:
            price = 0
        if not name or not category or price <= 0:
            return None
        return (name, description, category, price,
                1 if request.form.get("is_available") else 0)

    @app.route("/admin/menu/new", methods=["GET", "POST"])
    @admin_required
    def admin_menu_new():
        if request.method == "POST":
            data = read_item_form()
            if data is None:
                flash("Name, category and a positive price are required.", "danger")
            else:
                db = get_db()
                db.execute("INSERT INTO menu_items (name, description, category, price_cents, is_available) "
                           "VALUES (?,?,?,?,?)", data)
                db.commit()
                flash("Menu item added.", "success")
                return redirect(url_for("admin_menu"))
        return render_template("admin_menu_form.html", item=None)

    @app.route("/admin/menu/<int:item_id>/edit", methods=["GET", "POST"])
    @admin_required
    def admin_menu_edit(item_id):
        db = get_db()
        item = db.execute("SELECT * FROM menu_items WHERE id = ?", (item_id,)).fetchone()
        if item is None:
            abort(404)
        if request.method == "POST":
            data = read_item_form()
            if data is None:
                flash("Name, category and a positive price are required.", "danger")
            else:
                db.execute("UPDATE menu_items SET name=?, description=?, category=?, price_cents=?, "
                           "is_available=? WHERE id=?", data + (item_id,))
                db.commit()
                flash("Menu item updated.", "success")
                return redirect(url_for("admin_menu"))
        return render_template("admin_menu_form.html", item=item)

    @app.route("/admin/menu/<int:item_id>/delete", methods=["POST"])
    @admin_required
    def admin_menu_delete(item_id):
        db = get_db()
        db.execute("DELETE FROM menu_items WHERE id = ?", (item_id,))
        db.commit()
        flash("Menu item deleted.", "info")
        return redirect(url_for("admin_menu"))

    @app.route("/admin/orders")
    @admin_required
    def admin_orders():
        status = request.args.get("status", "")
        sql = ("SELECT o.*, u.name AS customer FROM orders o JOIN users u ON u.id = o.user_id")
        params = []
        if status in ORDER_STATUSES:
            sql += " WHERE o.status = ?"
            params.append(status)
        rows = get_db().execute(sql + " ORDER BY o.id DESC", params).fetchall()
        return render_template("admin_orders.html", orders=rows, status=status)

    @app.route("/admin/orders/<int:order_id>/status", methods=["POST"])
    @admin_required
    def admin_order_status(order_id):
        status = request.form.get("status", "")
        if status not in ORDER_STATUSES:
            abort(400)
        db = get_db()
        db.execute("UPDATE orders SET status = ? WHERE id = ?", (status, order_id))
        db.commit()
        flash(f"Order #{order_id} marked as {status}.", "success")
        return redirect(request.referrer or url_for("admin_orders"))

    @app.errorhandler(403)
    def forbidden(_e):
        return render_template("error.html", code=403, message="You do not have access to this page."), 403

    @app.errorhandler(404)
    def not_found(_e):
        return render_template("error.html", code=404, message="Page not found."), 404

    return app


if __name__ == "__main__":
    create_app().run(debug=os.environ.get("FLASK_DEBUG") == "1")
