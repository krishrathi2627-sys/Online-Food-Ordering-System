# System Design

## 1. Architecture

Three-tier layered architecture (MVC-style):

```mermaid
flowchart LR
    B[Browser<br/>HTML + CSS] -->|HTTP| R[Flask routes<br/>controllers]
    R --> T[Jinja2 templates<br/>views]
    R --> D[(SQLite<br/>database)]
    R --> S[Session<br/>cart + login]
```

| Layer | Implementation |
|-------|----------------|
| Presentation | `templates/*.html`, `static/style.css` |
| Application | `app.py` (routes, validation, authorisation, cart logic) |
| Data | `schema.sql` + SQLite file `food.db` |

## 2. Use Case Diagram

```mermaid
flowchart LR
    G([Guest]) --- U1(Browse / search menu)
    G --- U2(Manage cart)
    G --- U3(Register / Login)
    C([Customer]) --- U4(Checkout and pay)
    C --- U5(View order history)
    C --- U6(Cancel order)
    A([Admin]) --- U7(Manage menu)
    A --- U8(Update order status)
    A --- U9(View dashboard)
```

## 3. Entity Relationship Diagram

```mermaid
erDiagram
    USERS ||--o{ ORDERS : places
    ORDERS ||--|{ ORDER_ITEMS : contains
    MENU_ITEMS ||--o{ ORDER_ITEMS : "snapshotted into"
    USERS {
        int id PK
        string name
        string email UK
        string password_hash
        string role
        string address
        datetime created_at
    }
    MENU_ITEMS {
        int id PK
        string name
        string description
        string category
        int price_cents
        bool is_available
    }
    ORDERS {
        int id PK
        int user_id FK
        int total_cents
        string status
        string address
        string payment_method
        datetime created_at
    }
    ORDER_ITEMS {
        int id PK
        int order_id FK
        int item_id
        string name
        int price_cents
        int quantity
    }
```

## 4. Sequence Diagram: Place Order

```mermaid
sequenceDiagram
    actor C as Customer
    participant W as Flask App
    participant DB as SQLite
    C->>W: POST /cart/add/1
    W->>DB: verify item available
    W-->>C: cart updated (session)
    C->>W: POST /checkout (address, payment)
    W->>W: check login + CSRF
    W->>DB: read current prices
    W->>DB: INSERT order + order_items (one transaction)
    W-->>C: redirect to order confirmation
```

## 5. Order State Diagram

```mermaid
stateDiagram-v2
    [*] --> Placed
    Placed --> Preparing
    Placed --> Cancelled: customer or admin
    Preparing --> OutForDelivery
    OutForDelivery --> Delivered
    Delivered --> [*]
    Cancelled --> [*]
```

## 6. Route Map

| Method | URL | Access | Purpose |
|--------|-----|--------|---------|
| GET | `/` | Public | Menu, search, filter |
| GET/POST | `/register`, `/login` | Public | Authentication |
| POST | `/logout` | Any | End session |
| GET | `/cart` | Public | View cart |
| POST | `/cart/add/<id>`, `/cart/update/<id>`, `/cart/clear` | Public | Modify cart |
| GET/POST | `/checkout` | Customer | Place order |
| GET | `/orders`, `/orders/<id>` | Owner/Admin | Order history and detail |
| POST | `/orders/<id>/cancel` | Owner | Cancel while Placed |
| GET | `/admin` | Admin | Dashboard |
| GET/POST | `/admin/menu`, `/admin/menu/new`, `/admin/menu/<id>/edit`, `/admin/menu/<id>/delete` | Admin | Menu CRUD |
| GET | `/admin/orders` | Admin | All orders, filter |
| POST | `/admin/orders/<id>/status` | Admin | Update status |

## 7. Design Decisions
- **Integer money:** prices are stored in paise to avoid floating-point rounding errors.
- **Order snapshots:** `order_items` copies name and price, so editing the menu never changes history.
- **Server-side prices:** the cart stores only item ids and quantities; prices are always read from the database at checkout.
- **Application factory:** `create_app()` allows an isolated database per test.
- **Security:** hashed passwords, CSRF tokens, parameterised SQL, role checks via decorators, open-redirect protection on login.
