# Test Plan

**Strategy:** automated functional/integration tests with `pytest` and Flask's test client; each test uses a fresh temporary SQLite database. Run with `python -m pytest -v`.

| ID | Feature | Test function | Expected result | Status |
|----|---------|---------------|-----------------|--------|
| TC-01 | Menu, search, filter | `test_menu_shows_seeded_items`, `test_menu_search_and_category_filter` | Seeded items shown; filters narrow the list | Pass |
| TC-02 | Registration + login | `test_register_and_login` | Account created, user logged in | Pass |
| TC-03 | Duplicate email | `test_duplicate_email_rejected` | Error message shown | Pass |
| TC-04 | Weak password | `test_short_password_rejected` | Error message shown | Pass |
| TC-05 | Invalid credentials | `test_invalid_login` | "Invalid email or password" | Pass |
| TC-06 | Cart totals | `test_cart_add_update_total` | 2 × ₹249 = ₹498.00; qty 0 removes item | Pass |
| TC-07 | Checkout needs login | `test_checkout_requires_login` | Redirect to login | Pass |
| TC-08 | Place order | `test_place_order_empties_cart` | Order #1 created, cart empty | Pass |
| TC-09 | Checkout validation | `test_checkout_validation` | Missing address rejected | Pass |
| TC-10 | Admin access control | `test_customer_cannot_access_admin` | HTTP 403 | Pass |
| TC-11 | Admin status update | `test_admin_updates_order_status` | Status changes to Delivered | Pass |
| TC-12 | Menu CRUD | `test_admin_menu_crud` | Item created then deleted | Pass |
| TC-13 | Cancel order | `test_customer_can_cancel_only_placed_order` | Allowed once, refused afterwards | Pass |
| TC-14 | Order privacy | `test_user_cannot_view_other_users_order` | HTTP 403 | Pass |
| TC-15 | CSRF protection | `test_csrf_enforced_when_enabled` | POST without token → HTTP 400 | Pass |

## Manual test checklist
- [ ] Layout is usable at 375 px width (mobile)
- [ ] Logout button clears the session
- [ ] Cart count in the header updates after adding items
- [ ] Admin can see an order placed by a customer

## Defect found during testing
TC-15 initially failed: the CSRF check compared `None == None` when a session had no token yet, so tokenless POSTs were accepted. Fixed by requiring a non-empty session token and using constant-time comparison (`secrets.compare_digest`).
