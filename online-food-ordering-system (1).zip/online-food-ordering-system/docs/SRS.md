# Software Requirements Specification (SRS)
## Online Food Ordering System

Version 1.0 · Prepared for the Software Engineering course (IEEE 830 style)

---

## 1. Introduction

### 1.1 Purpose
This document specifies the functional and non-functional requirements of the **Online Food Ordering System (OFOS)**, a web application that lets customers browse a restaurant menu, place food orders online, and track them, while allowing restaurant staff to manage the menu and process orders.

### 1.2 Scope
OFOS is a single-restaurant web application. It provides:
- Customer registration, login and profile address storage
- Menu browsing, search and category filtering
- Shopping cart, checkout with simulated payment and order history
- Order cancellation (before preparation starts)
- Admin dashboard, menu management (CRUD) and order status management

**Out of scope (future work):** real payment gateway, multi-restaurant support, live GPS delivery tracking, email/SMS notifications, ratings and reviews.

### 1.3 Definitions
| Term | Meaning |
|------|---------|
| Customer | A registered user who orders food |
| Admin | Restaurant staff who manage menu and orders |
| Order status | Placed → Preparing → Out for Delivery → Delivered (or Cancelled) |
| CSRF | Cross-Site Request Forgery |

### 1.4 References
IEEE Std 830-1998; Flask documentation; SQLite documentation.

---

## 2. Overall Description

### 2.1 Product Perspective
A standalone, three-tier web application: browser (presentation) → Flask (application logic) → SQLite (data).

### 2.2 User Classes
| User | Characteristics |
|------|-----------------|
| Guest | Can browse the menu and use the cart; must log in to check out |
| Customer | Can order, view and cancel own orders |
| Admin | Full control of menu and orders; sees dashboard statistics |

### 2.3 Operating Environment
Any modern browser (Chrome, Firefox, Edge, Safari); server runs Python 3.9+ on Windows, Linux or macOS.

### 2.4 Constraints and Assumptions
- Payments are simulated (no real money moves).
- Single currency (INR, prices stored as integer paise to avoid floating-point errors).
- One restaurant, one admin role.

---

## 3. Functional Requirements

### 3.1 Authentication and Accounts
| ID | Requirement | Priority |
|----|-------------|----------|
| FR-1 | The system shall allow a visitor to register with name, email, password and optional address | High |
| FR-2 | The system shall reject duplicate emails and passwords shorter than 6 characters | High |
| FR-3 | The system shall authenticate users by email and password and store passwords only as salted hashes | High |
| FR-4 | The system shall allow logout and clear the session | High |

### 3.2 Menu
| ID | Requirement | Priority |
|----|-------------|----------|
| FR-5 | The system shall display all available menu items grouped by category with name, description and price | High |
| FR-6 | The system shall support keyword search and category filtering | Medium |
| FR-7 | Unavailable items shall not be shown to customers or be orderable | High |

### 3.3 Cart and Checkout
| ID | Requirement | Priority |
|----|-------------|----------|
| FR-8 | The system shall let any visitor add items to a cart, change quantities (max 20 per item), remove items and clear the cart | High |
| FR-9 | The system shall compute the cart total from current database prices | High |
| FR-10 | Checkout shall require login, a delivery address and a payment method | High |
| FR-11 | On checkout the system shall create an order, snapshot item names and prices, and empty the cart | High |

### 3.4 Order Management (Customer)
| ID | Requirement | Priority |
|----|-------------|----------|
| FR-12 | A customer shall view a list and details of their own orders | High |
| FR-13 | A customer shall be able to cancel an order only while its status is "Placed" | Medium |
| FR-14 | A customer shall not be able to view another customer's orders | High |

### 3.5 Administration
| ID | Requirement | Priority |
|----|-------------|----------|
| FR-15 | An admin shall add, edit, delete and enable/disable menu items | High |
| FR-16 | An admin shall view all orders, filter by status and update status | High |
| FR-17 | The admin dashboard shall show total orders, revenue (excluding cancelled), customer count and item count | Medium |
| FR-18 | Admin pages shall be inaccessible to non-admin users (HTTP 403) | High |

---

## 4. Non-Functional Requirements

| ID | Category | Requirement |
|----|----------|-------------|
| NFR-1 | Security | Passwords hashed (PBKDF2/scrypt via Werkzeug); all state-changing requests protected by CSRF tokens; SQL queries parameterised; role-based access control |
| NFR-2 | Performance | Pages shall load in under 2 seconds on a typical broadband connection with up to 100 concurrent users (academic target) |
| NFR-3 | Usability | Responsive layout usable on mobile and desktop; clear flash messages for every action |
| NFR-4 | Reliability | Order creation is atomic (single DB transaction); foreign keys enforced |
| NFR-5 | Maintainability | Modular code, automated tests (pytest), CI on every push |
| NFR-6 | Portability | Runs anywhere Python runs; no external database server needed |
| NFR-7 | Data integrity | Monetary values stored as integers; order history unaffected by later menu changes |

---

## 5. Use Cases

### UC-1 Place an Order
- **Actor:** Customer
- **Pre-condition:** Customer is logged in; cart has ≥ 1 item
- **Main flow:** 1) Customer opens cart → 2) proceeds to checkout → 3) confirms address → 4) selects payment method → 5) submits → 6) system creates the order with status *Placed* → 7) system shows the order confirmation
- **Alternate flows:** A1) Address empty → error, stay on checkout. A2) An item became unavailable → error message.
- **Post-condition:** Order saved, cart empty.

### UC-2 Cancel an Order
- **Actor:** Customer · **Pre-condition:** Own order has status *Placed*
- **Main flow:** Open order → click Cancel → system sets status *Cancelled*
- **Alternate:** Status is not *Placed* → system refuses with message.

### UC-3 Manage Menu
- **Actor:** Admin · **Main flow:** Open Manage Menu → add / edit / delete / toggle availability → system validates (name, category, price > 0) and saves.

### UC-4 Process Orders
- **Actor:** Admin · **Main flow:** Open Manage Orders → filter by status → change an order's status through the lifecycle.

### UC-5 Register / Login
- **Actor:** Guest · **Main flow:** Fill form → system validates → account created → login with credentials.

---

## 6. External Interface Requirements
- **User interface:** HTML5/CSS3 server-rendered pages (Jinja2 templates).
- **Database interface:** SQLite via Python `sqlite3`.
- **Hardware interface:** none.
- **Communication:** HTTP/HTTPS (HTTPS recommended in production).

## 7. Requirements Traceability

| Requirement | Test cases (see `TEST_PLAN.md`) |
|-------------|----------------------------------|
| FR-1, FR-2 | TC-02, TC-03, TC-04 |
| FR-3 | TC-02, TC-05 |
| FR-5, FR-6 | TC-01 |
| FR-8, FR-9 | TC-06 |
| FR-10, FR-11 | TC-07, TC-08, TC-09 |
| FR-13 | TC-13 |
| FR-14, FR-18 | TC-10, TC-14 |
| FR-15, FR-16 | TC-11, TC-12 |
| NFR-1 | TC-15 |
